// Database
const express= require("express");
const fs= require("fs");
const path= require("path");

const app= express();   

app.use(express.json());
app.use(express.static(path.join(__dirname, "../Frontend")));
const FILE= path.join(__dirname, "reviews.json");

if (!fs.existsSync(FILE)) {
  fs.writeFileSync(FILE, "[]");
}

app.get("/", (req, res) => {
    res.redirect("/Html/index.html")
});

app.get("/api/comments", (req, res) => {
    try {
        const data = fs.readFileSync(FILE, "utf8");
        const reviews = JSON.parse(data);

        res.json(reviews);
    } catch (error) {
        console.error("Error loading reviews:", error);
        res.status(500).json({
            error: "Failed to load reviews."
        });
    }
});

app.post("/api/comments", (req, res) => {
    try {
        const name = req.body.name?.trim();
        const email = req.body.email?.trim();
        const comment = req.body.comment?.trim();

        if (!name) {
            return res.status(400).json({
                error: "Please enter your name."
            });
        }

        if (!comment) {
            return res.status(400).json({
                error: "Please enter your comment."
            });
        }

        const data = fs.readFileSync(FILE, "utf8");
        const reviews = JSON.parse(data);

        const newReview = {
            id: Date.now(),
            name: name,
            email: email || "",
            comment: comment
        };

        reviews.push(newReview);

        fs.writeFileSync(
            FILE,
            JSON.stringify(reviews, null, 2)
        );

        res.status(201).json(newReview);

    } catch (error) {
        console.error("Error saving review:", error);

        res.status(500).json({
            error: "Failed to save review."
        });
    }
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});

